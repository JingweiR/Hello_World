# Get CIFAR10
wget http://filecremers3.informatik.tu-muenchen.de/~dl4cv/segmentation_data.zip
unzip segmentation_data.zip
rm segmentation_data.zip
