# Get CIFAR10
wget http://filecremers3.informatik.tu-muenchen.de/~dl4cv/cifar10_train.zip 
tar -xzvf cifar10_train.zip
rm cifar10_train.zip 
